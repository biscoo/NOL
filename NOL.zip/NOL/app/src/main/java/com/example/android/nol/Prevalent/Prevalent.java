package com.example.android.nol.Prevalent;

import com.example.android.nol.Model.Users;

public class Prevalent {
    private static Users currentOnlineUser;
}
